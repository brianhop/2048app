//
//  assign3App.swift
//  assign3
//
//  Created by Brian Hopkins  on 10/10/21.
//

import SwiftUI

@main
struct assign3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
